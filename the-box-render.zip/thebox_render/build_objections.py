#!/usr/bin/env python3
"""Build /data/objections.json from the source box_data.json.

For 40+ priority objections we provide POLISHED Still Point voice copy.
For the rest we NORMALIZE the existing track1/track2/close fields into
the new schema so editing is uniform.

Schema (per objection):
  id              short stable id (code, e.g. "G-01")
  category        section name
  category_code   single-letter section code
  title           the customer-facing objection (one line)
  customer_line   what the customer actually says (short version, 8-14 words)
  signal          single word/short phrase: what they're really telling you
  soft_open       calm reframe, removes emotional resistance. 1-2 short sentences.
  pivot           shift to structure / depth. 1-2 short sentences.
  close           the close line; assigns ownership without pressure. 1-2 short sentences.
  pushback        if they push back, what to say next. 1 sentence.
  follow_ups      list of 2-3 short follow-up prompts or questions
  aliases         search aliases
  keywords        comma list for search
  polished        bool — True if Still Point team has rewritten this entry
  page            page in field manual (if known)
"""
import json
import os
import re

SRC = os.path.join(os.path.dirname(__file__), "..", "the-box-execution-review", "box_data.json")
OUT = os.path.join(os.path.dirname(__file__), "data", "objections.json")

# Signal mapping by category (default)
DEFAULT_SIGNAL = {
    "Trust & Credibility": "trust",
    "GAP Protection": "risk",
    "Lease-Specific": "control",
    "Payment & Budget": "payment",
    "Timing & Decision": "delay",
    "Warranty / Service Plan": "risk",
    "General & Brush-Offs": "control",
}

# ============================================================
# POLISHED ENTRIES — Still Point voice, finance-office grounded.
# Add or revise here. The script will use these as overrides.
# ============================================================
POLISHED = {
    # ----- GAP (8 polished) -----
    "G-01": {
        "customer_line": "I don't need GAP — I'm a good driver.",
        "signal": "risk",
        "soft_open": "If GAP were for bad drivers, we'd sell it in traffic court.",
        "pivot": "GAP isn't about how you drive. It's about the gap between what insurance pays and what you still owe when somebody else, or the weather, totals your car.",
        "close": "Skill doesn't close that gap. The lender does one math, the insurance company does another, and whatever's between them lands on you.",
        "pushback": "You can be the best driver on the road and still get hit at a stoplight — the question is who writes the check when you do.",
        "follow_ups": [
            "Has your insurance ever told you the actual payout on a total loss?",
            "How much down are you putting — five percent, ten, none?",
            "Want me to show you the gap on this exact deal in writing?"
        ],
    },
    "G-02": {
        "customer_line": "My insurance already covers that.",
        "signal": "risk",
        "soft_open": "Most people think that, and they're half right.",
        "pivot": "Insurance pays the car's value the day it's totaled. GAP pays the difference between that number and what you actually owe the bank. Two different checks, two different jobs.",
        "close": "If insurance covered the loan balance, lenders wouldn't sell GAP — they'd just self-insure.",
        "pushback": "Call your agent right now and ask if your policy pays your loan off after a total loss. I'll wait.",
        "follow_ups": [
            "When was the last time you checked your actual ACV on this vehicle?",
            "Do you carry a deductible? GAP usually covers that too.",
            "Want to see what the gap looks like in month twelve?"
        ],
    },
    "G-03": {
        "customer_line": "I'm putting money down, so I don't need it.",
        "signal": "risk",
        "soft_open": "Money down helps. It just doesn't help as fast as you think.",
        "pivot": "The car drops faster than the loan in the first eighteen months. Your down payment buys you a few months of cushion, not a few years of it.",
        "close": "GAP protects the part of the loan your down payment didn't reach.",
        "pushback": "If your down payment did the job, lenders wouldn't keep selling GAP on cash-heavy deals — and they do.",
        "follow_ups": [
            "How long do you plan to keep the car?",
            "Are you financing the taxes and fees too?",
            "Want me to draw the depreciation curve on this one?"
        ],
    },
    "G-04": {
        "customer_line": "GAP is overpriced.",
        "signal": "price",
        "soft_open": "Compared to what? Most people are pricing it against nothing.",
        "pivot": "GAP is a one-time number against a five-year loan. The real comparison is what an uncovered total loss costs — usually thousands, sometimes more than the down payment.",
        "close": "It's the cheapest line on the menu and the only one that handles total loss.",
        "pushback": "If you total this car in year two, the bill is the same whether you bought GAP or not — one of those bills is yours, the other isn't.",
        "follow_ups": [
            "What did you think GAP cost before today?",
            "Want me to show you the breakdown per month?",
            "Have you priced GAP through your insurance? Compare them side by side."
        ],
    },
    "G-05": {
        "customer_line": "I'll just get GAP through my insurance.",
        "signal": "risk",
        "soft_open": "Some carriers do offer it. It's usually not the same product.",
        "pivot": "Most insurance GAP riders cap at 25 percent over ACV and exclude rolled-in negative equity. Ours pays the actual loan balance, including what you carried over.",
        "close": "Same word, different coverage. Ask your agent for the cap and the exclusions in writing.",
        "pushback": "If yours covers the full balance with no cap, take it — but get that in writing today, not when you need it.",
        "follow_ups": [
            "Did you roll negative equity into this loan?",
            "Want me to read you the cap language on this policy?",
            "What does your agent quote on GAP per month?"
        ],
    },
    "G-06": {
        "customer_line": "I'm not financing long enough to need it.",
        "signal": "risk",
        "soft_open": "The first two years are exactly when you need it most.",
        "pivot": "A new car loses the largest chunk of its value in the first twenty-four months. That's the same window where the loan barely moves. That's the gap.",
        "close": "Short loans don't shrink the gap, they shrink the time you have to refinance out of it.",
        "pushback": "If you total it in month fourteen of a forty-eight-month loan, the math doesn't care how short the loan is.",
        "follow_ups": [
            "What's your term on this deal?",
            "Are you planning to pay it off early?",
            "Want me to show the gap at month twelve versus month thirty-six?"
        ],
    },
    "G-07": {
        "customer_line": "I have full coverage, that's enough.",
        "signal": "risk",
        "soft_open": "Full coverage is a marketing word, not a contract term.",
        "pivot": "Full coverage means comp and collision. It pays the car's value. It does not pay your loan. GAP is the part nobody tells you about until the day you need it.",
        "close": "Two different products, two different jobs. You already bought one. This is the other.",
        "pushback": "Ask any claims adjuster what they tell people the day a loan balance is higher than the payout — they say 'call your finance manager.'",
        "follow_ups": [
            "What's your collision deductible?",
            "Has your carrier ever explained ACV to you?",
            "Want me to walk you through what your insurance pays versus what you'd owe?"
        ],
    },
    "G-08": {
        "customer_line": "I'll just pay the difference out of pocket if something happens.",
        "signal": "risk",
        "soft_open": "Some people can. Most who say that haven't priced the difference.",
        "pivot": "Average gap on a new-car total loss right now runs five to nine thousand. That's not the down payment on the next car — that's a separate bill on top of it.",
        "close": "GAP isn't there to save the car. It's there to keep the next car from being twice as expensive.",
        "pushback": "If you total this one tomorrow, would you rather be writing me a check today for a few bucks a month, or writing your insurance a check for the gap?",
        "follow_ups": [
            "What would five thousand cash today do to your next deal?",
            "Have you ever totaled a financed car before?",
            "Want me to show you a real claim from last quarter?"
        ],
    },

    # ----- Warranty / Service Plan (8 polished) -----
    "W-01": {
        "customer_line": "That's a lot of money for a service contract. I don't see the value.",
        "signal": "price",
        "soft_open": "Fair. Nobody pays for what they can't see yet.",
        "pivot": "The value isn't the contract. The value is what one repair costs without it. Modern transmissions, hybrid batteries, sensors — the cheap ones start at four thousand.",
        "close": "If this were free, you'd take it. So we're not arguing about the product, we're agreeing on the price.",
        "pushback": "Would you take it if it were free? Then what we're really doing is choosing how to pay for repairs — in monthly cents or in one painful number.",
        "follow_ups": [
            "What's the most expensive repair you've ever paid out of pocket?",
            "Are you keeping this past the factory warranty?",
            "Want me to price one transmission claim against the contract?"
        ],
    },
    "W-02": {
        "customer_line": "I've never used one before.",
        "signal": "prior",
        "soft_open": "Most people who say that mean they've never had to use one. Different statement.",
        "pivot": "Service contracts are like seatbelts. The first time you actually need one is the only time you'll judge whether it was worth it.",
        "close": "You're not buying the contract. You're buying the option to not be surprised.",
        "pushback": "Your last car was probably under warranty when you sold it. This one's going to outlive that window.",
        "follow_ups": [
            "How long did you keep your last car?",
            "Did any repair ever catch you by surprise?",
            "Want me to show what's covered and what isn't?"
        ],
    },
    "W-03": {
        "customer_line": "The car is new — it shouldn't break.",
        "signal": "risk",
        "soft_open": "It shouldn't. But the parts that go wrong on new cars now are different than they used to be.",
        "pivot": "Engines and transmissions are reliable. Infotainment, ADAS sensors, electronic modules — those fail more, and they cost more than the engine work used to.",
        "close": "A new car isn't a guarantee. It's a probability. The contract is what you do with the rest of the probability.",
        "pushback": "Pull up the most common claims on this exact model — I'll show you what we've paid out the last year.",
        "follow_ups": [
            "What's the warranty length on this model?",
            "Have you priced an ADAS camera replacement?",
            "Want me to show you the actual claim history on this vehicle?"
        ],
    },
    "W-04": {
        "customer_line": "I'll just buy one later if I need it.",
        "signal": "delay",
        "soft_open": "You can. It just won't be this one, and it won't be this price.",
        "pivot": "After-market contracts are sold by call centers and priced for their cost of marketing. The one in front of you is priced into the loan and underwritten by the manufacturer or a major carrier.",
        "close": "Later isn't a discount. It's almost always a markup.",
        "pushback": "If something breaks between now and then, the contract you buy after that won't cover it — pre-existing.",
        "follow_ups": [
            "Want me to price a third-party contract on this car right now?",
            "Are you okay if a repair happens during the gap?",
            "When does the factory warranty actually end?"
        ],
    },
    "W-05": {
        "customer_line": "I do my own repairs.",
        "signal": "control",
        "soft_open": "Respect. That's getting rarer, and I mean that.",
        "pivot": "Most of what fails on this car now isn't a wrench job. It's a coded module, a calibrated sensor, a dealer-only software flash. The labor's not the issue — the access is.",
        "close": "You can still do your own oil and brakes. The contract handles the parts you can't legally touch.",
        "pushback": "Ask any independent shop what they charge for an ADAS recalibration — most send it back to us.",
        "follow_ups": [
            "When was the last time you opened a transmission?",
            "Have you priced a dealer-only diagnostic on this car?",
            "Want me to show what's covered that you can't do at home?"
        ],
    },
    "W-06": {
        "customer_line": "Manufacturer warranty covers everything.",
        "signal": "risk",
        "soft_open": "It covers a lot. The question is what happens in year four.",
        "pivot": "Factory warranty is three years, thirty-six thousand miles on most things. The expensive failures — sensors, electronics, hybrid components — usually show up at fifty, sixty, seventy thousand.",
        "close": "The contract starts where the factory stops. That's the only point.",
        "pushback": "When you sold your last car, was it still under factory warranty? Most people answer no.",
        "follow_ups": [
            "How long do you typically keep a car?",
            "Are you over warranty on miles or years first?",
            "Want me to show you the coverage gap on paper?"
        ],
    },
    "W-07": {
        "customer_line": "These contracts never pay out.",
        "signal": "trust",
        "soft_open": "Some don't. The ones we sell do — that's why we sell them and not the others.",
        "pivot": "Our claims ratio on this contract is public. The carrier has to file it. I can pull the number for this state if you want it.",
        "close": "If it didn't pay, we wouldn't write the same one twice. Buyers come back. Bad contracts don't survive that.",
        "pushback": "Show me the contract you heard about — half the time it's a name nobody in the building has ever sold.",
        "follow_ups": [
            "Where did you hear the bad story?",
            "Want me to pull the claims data on this carrier?",
            "Would seeing a real paid-out claim change your read?"
        ],
    },
    "W-08": {
        "customer_line": "It's cheaper to fix it when it breaks.",
        "signal": "price",
        "soft_open": "Sometimes. Until the one repair that isn't.",
        "pivot": "The math only works if every repair is small. One transmission, one hybrid battery, one electronics package — and the contract was the cheaper number all along.",
        "close": "You're not paying for the average repair. You're paying to not get hit by the worst one.",
        "pushback": "If you're right, you lose a few bucks a month. If I'm right, you save thousands. Asymmetric.",
        "follow_ups": [
            "What's the most you could write a check for tomorrow without flinching?",
            "Want to see the average claim size on this contract?",
            "How long are you keeping the car?"
        ],
    },

    # ----- Payment & Budget (7 polished) -----
    "P-01": {
        "customer_line": "I don't want to put any money down.",
        "signal": "payment",
        "soft_open": "Holding onto cash is fine. There's just a cost to it.",
        "pivot": "Whatever you don't put down, the bank rents to you at your interest rate for the full term. Twenty-five hundred you keep today costs you about seven hundred over the loan.",
        "close": "You're not avoiding the payment. You're choosing whether to pay it once now or stretch it across seventy-two months.",
        "pushback": "Keep the cash if you want. Just go in knowing it's the most expensive cash you own this year.",
        "follow_ups": [
            "What's your rate on this deal?",
            "Want me to run the same payment with five hundred down?",
            "Are you using that cash for something specific?"
        ],
    },
    "P-02": {
        "customer_line": "I can't afford the payment.",
        "signal": "payment",
        "soft_open": "Then let's not pretend the payment is the only number. Let's find the one that works.",
        "pivot": "We can move the term, change the down, restructure the products — there are four ways to land this. Tell me which one you'd actually use the car for, and I'll build to that.",
        "close": "Affordable isn't a fixed number. It's the version of this deal that fits the life you're actually driving into.",
        "pushback": "What payment, exactly, would you sign for today if everything else stayed the same?",
        "follow_ups": [
            "What's the exact monthly number you came in expecting?",
            "What's the longest term you'd consider?",
            "How does the payment compare to what you're driving now?"
        ],
    },
    "P-03": {
        "customer_line": "The payment is too high.",
        "signal": "payment",
        "soft_open": "Compared to what?",
        "pivot": "Most people are comparing the new payment to what they were paying on a car they've been driving for four years. Different car, different rate, different world.",
        "close": "Tell me your real number. We work backward from there.",
        "pushback": "If we hit your number, are we signing tonight? If yes, let's find it. If no, the number isn't actually the problem.",
        "follow_ups": [
            "What were you paying on the last car?",
            "Was that a lease or a loan?",
            "What's your hard ceiling — and what's your comfort number?"
        ],
    },
    "P-04": {
        "customer_line": "I want a shorter term.",
        "signal": "control",
        "soft_open": "Shorter terms are smart. They're also less flexible.",
        "pivot": "A shorter term gives you a higher payment and faster equity. A longer term gives you lower payment and the option to pay it down on your own schedule. Same loan, different control.",
        "close": "You can always pay a long loan short. You can't pay a short loan long.",
        "pushback": "If money's tight one month, would you rather be obligated to a big payment or have room to breathe?",
        "follow_ups": [
            "Is there a year of income variability ahead?",
            "Want to see the payment on three terms side by side?",
            "Is the goal to be debt-free, or to be flexible?"
        ],
    },
    "P-05": {
        "customer_line": "Can you take that off the payment?",
        "signal": "payment",
        "soft_open": "I can. The car still costs the same when I do.",
        "pivot": "Removing a product doesn't shrink the price of being wrong about not having it. It just moves the cost off the contract and onto your credit card in eighteen months.",
        "close": "We can adjust. Let's make sure we're cutting the right thing, not the cheapest thing.",
        "pushback": "Which one are you willing to bet against — the engine, the gap, or the tires?",
        "follow_ups": [
            "Which product feels least relevant to how you drive?",
            "Want me to rebuild the menu around the payment you want?",
            "What would you actually use the cash for if we cut it?"
        ],
    },
    "P-06": {
        "customer_line": "Can you get me a lower rate?",
        "signal": "price",
        "soft_open": "Probably not by arguing. By restructuring, yes.",
        "pivot": "Rate is what the bank decides. Term, down, and product mix is what we decide. Most of the time, the payment you want lives in the second column, not the first.",
        "close": "Let's stop chasing the rate and start moving the levers we actually control.",
        "pushback": "I can shop banks again, but the move that lands you where you want to be is usually structure, not basis points.",
        "follow_ups": [
            "What rate were you expecting?",
            "Have you pulled your credit recently?",
            "Want to see term-versus-down tradeoffs in writing?"
        ],
    },
    "P-07": {
        "customer_line": "I'm on a budget.",
        "signal": "payment",
        "soft_open": "Everyone is. The question is what budget actually means here.",
        "pivot": "Budget is two numbers — the monthly that fits today, and the surprise expense that breaks the budget if you don't plan for it. Most people only budget for the first one.",
        "close": "Protecting the budget means protecting both numbers. Otherwise the first one always loses to the second.",
        "pushback": "Tell me your budget and I'll build to it. But if a thousand-dollar repair shows up next year, we both know which number wins.",
        "follow_ups": [
            "What's the monthly target you came in with?",
            "Is there an emergency fund behind that number?",
            "Have you been hit by a surprise repair in the last two years?"
        ],
    },

    # ----- Cash buyer / paying cash (3 polished — found in X section) -----
    "X-04": {  # we'll re-map any cash entry; will create if not present
        "customer_line": "I'm paying cash, so I don't need any of this.",
        "signal": "control",
        "soft_open": "Paying cash is great. It just doesn't change what the car costs to own.",
        "pivot": "Cash buyers carry every repair, every gap on a total loss, every surprise — alone. The products are about your cash, not the lender's.",
        "close": "If anything, cash buyers are the ones who should look the hardest. There's no bank between you and the bill.",
        "pushback": "When you wrote that check today, did you write it expecting to write another one for a repair in three years?",
        "follow_ups": [
            "How long are you keeping this car?",
            "What would you do if a major repair hit next year?",
            "Want me to show what coverage looks like on a cash deal?"
        ],
    },

    # ----- Spouse / Think (4 polished, T section) -----
    "T-01": {
        "customer_line": "I need to think about it.",
        "signal": "delay",
        "soft_open": "Fair. Let me ask one thing before you do.",
        "pivot": "When people say they want to think about it, usually one of three things is true — the price isn't clear, the value isn't clear, or the decision isn't actually yours alone. Which one is it?",
        "close": "Whichever one it is, we can sort it now or you can leave with three questions instead of one.",
        "pushback": "Thinking about it doesn't change the price, the car, or the coverage. The only thing it changes is whether you're protected on the drive home.",
        "follow_ups": [
            "What specifically would you want to think about?",
            "Is there someone else who needs to be in the decision?",
            "What would make you decide today versus next week?"
        ],
    },
    "T-02": {
        "customer_line": "I need to talk to my spouse / wife / husband / partner.",
        "signal": "spouse",
        "soft_open": "Of course. Smart move.",
        "pivot": "Let's send them a clean picture. Phone, speaker, two minutes — I'll walk them through the same thing I walked you through, no surprises.",
        "close": "If they have one question, we answer it now. If they have ten, we put it on hold. Either way, you're not driving home with a guess.",
        "pushback": "If they need the room, I'll step out. The worst version of this is you trying to explain a finance menu from your driveway.",
        "follow_ups": [
            "Do they usually want the numbers or the bottom line?",
            "Is this their first time buying with you, or your tenth?",
            "Want me to text them the breakdown so they can review on their own?"
        ],
    },
    "T-03": {
        "customer_line": "I want to sleep on it.",
        "signal": "delay",
        "soft_open": "Sleep is good. It rarely changes the math, though.",
        "pivot": "Tomorrow's version of this deal is the same car, the same payment, and the same questions. The only thing that changes is whether the car is still here at the price we built it at.",
        "close": "Sleep is for unanswered questions. If you have one I haven't answered, ask it now and we don't need the sleep.",
        "pushback": "What would you need to know in the morning that you can't ask me in the next five minutes?",
        "follow_ups": [
            "What's the one question still in your head?",
            "Has a deal ever gotten better by waiting overnight?",
            "Are we waiting on a person, a number, or a feeling?"
        ],
    },
    "T-04": {
        "customer_line": "I want to shop around.",
        "signal": "control",
        "soft_open": "You should. Shop the car. Shop the price. Then come back.",
        "pivot": "The products in front of you aren't shopped on the lot — they're shopped on the contract. Compare what's covered, who underwrites, and what the deductible is. That's the only fair comparison.",
        "close": "If somebody beats this in writing, I'll match it. If nobody does, we both know what to do.",
        "pushback": "Most of what gets called 'cheaper' is a different product with a different name on a different page. Bring it in and we'll line them up.",
        "follow_ups": [
            "What part of the deal are you most worried about?",
            "Have you priced the same car at another dealer?",
            "Want me to give you a checklist to shop with?"
        ],
    },

    # ----- Trust / Finance skepticism (4 polished, C section) -----
    "C-01": {
        "customer_line": "I don't trust finance managers.",
        "signal": "trust",
        "soft_open": "Fair. The stereotype exists for a reason.",
        "pivot": "I'm not here to convince you to like me. I'm the person who has to look you in the eye when something on this car breaks and you don't have a way to pay for it.",
        "close": "Everything I show you works the same whether you trust me or you never think about me again after today.",
        "pushback": "You don't have to take my word for anything — read the page, ask the question, sign only what makes sense.",
        "follow_ups": [
            "What's the last thing a finance manager did that lost your trust?",
            "Would seeing the contract language change anything?",
            "Is there a specific product you're skeptical of?"
        ],
    },
    "C-02": {
        "customer_line": "I feel like I'm being sold.",
        "signal": "trust",
        "soft_open": "I get it. If I were sitting where you are, I'd be checking my pockets too.",
        "pivot": "Here's the truth — my biggest risk isn't that I don't sell you something. It's that you're back in eighteen months for a repair I knew was coming and didn't protect you from.",
        "close": "I'd rather you be annoyed at me now for five minutes than mad at me for three years.",
        "pushback": "If you'd rather I just hand you the contract and walk out, I will. The product still does its job either way.",
        "follow_ups": [
            "What about the pitch felt off?",
            "Would you prefer the menu first and the conversation second?",
            "What's the single product you'd consider, if any?"
        ],
    },
    "C-13": {
        "customer_line": "This benefits you more than me.",
        "signal": "trust",
        "soft_open": "It benefits both of us. That's how the building stays open.",
        "pivot": "Where you're right — I get paid when you say yes. Where you're wrong — I also get paid when you say no, just less. So my incentive is to keep you a customer for ten years, not for tonight.",
        "close": "If this only worked for me, returning customers wouldn't exist. They do.",
        "pushback": "Ask any of the names on the wall over there if I'd sell them something that didn't work — they'd be the first to tell you.",
        "follow_ups": [
            "What part feels lopsided?",
            "Want me to show you the math on what this saves you?",
            "Is there a version of this you'd say yes to?"
        ],
    },
    "C-15": {
        "customer_line": "I just want honesty.",
        "signal": "trust",
        "soft_open": "Same. Let's do that.",
        "pivot": "Here's the honest read — the car costs what it costs, the rate is what the bank approved, and the products on the menu are real coverage with real exclusions. Anything on this page I can read to you, word for word.",
        "close": "Tell me which part you want the truth on, and I'll give it to you flat.",
        "pushback": "If there's a question you're afraid to ask because you think I won't answer it, that's the one you should ask first.",
        "follow_ups": [
            "What part of the deal do you feel least clear on?",
            "Has anyone in this process not been straight with you?",
            "What does 'fair' look like to you on this car?"
        ],
    },

    # ----- Lease (5 polished, L section) -----
    "L-01": {
        "customer_line": "I'm leasing, I don't need protection.",
        "signal": "control",
        "soft_open": "Leasing's a great move. It doesn't remove responsibility, though.",
        "pivot": "On a lease, you're still on the hook for damage, excess wear, mileage, and condition at turn-in. Protection isn't about the car — it's about not paying for someone else's car at the end of three years.",
        "close": "Lease protection exists for one reason: to keep a temporary car from creating permanent costs.",
        "pushback": "Read your lease agreement on the disposition fee and excess wear — that's what we're insuring against.",
        "follow_ups": [
            "How many miles a year are you driving?",
            "Have you ever turned in a lease before?",
            "What did your last turn-in actually cost?"
        ],
    },
    "L-02": {
        "customer_line": "I'm only keeping it three years.",
        "signal": "control",
        "soft_open": "Three years is plenty of time for one bad month.",
        "pivot": "Lease wear-and-tear charges and mileage overages don't wait for year six. They show up at turn-in, and they're priced by the manufacturer, not by you.",
        "close": "You're not protecting the car. You're protecting the bill that shows up the day you hand it back.",
        "pushback": "Most people who skip protection don't think about it again until the inspector walks around the car with a clipboard.",
        "follow_ups": [
            "What did the last turn-in bill look like?",
            "Are kids, pets, or commuters in this car?",
            "Want to see the wear charges in writing?"
        ],
    },
    "L-03": {
        "customer_line": "The lease already includes everything.",
        "signal": "trust",
        "soft_open": "It includes the car, the warranty, and a payment. Not the surprises.",
        "pivot": "The lease covers manufacturer defects, not your life. Tires, wheels, dings, key replacements, mileage — that's all on you at turn-in.",
        "close": "Two different things — what the manufacturer promised the bank, and what you'll be asked to write a check for at the end.",
        "pushback": "Ask for the wear-and-tear schedule on this lease — I'll read it with you line by line.",
        "follow_ups": [
            "Have you read the disposition section of the lease?",
            "What's your annual mileage allowance?",
            "Want to see what a typical turn-in bill looks like?"
        ],
    },
    "L-04": {
        "customer_line": "I'll just buy the car at lease end.",
        "signal": "delay",
        "soft_open": "Maybe. Most people who say that don't.",
        "pivot": "Buying out a lease in year three only makes sense if the residual is lower than the market value. Otherwise you're paying retail for a used car you already drove for three years.",
        "close": "Protect the lease as a lease. If you buy it later, great — that's a separate decision in three years, not today.",
        "pushback": "Lease buyouts are a real path. They just don't change what you need between now and then.",
        "follow_ups": [
            "What's your residual on this car?",
            "Have you priced the same model used at year three?",
            "Are you sure you'll want this same car in 2027?"
        ],
    },
    "L-05": {
        "customer_line": "Excess wear is no big deal.",
        "signal": "risk",
        "soft_open": "Until the inspector walks the car at turn-in.",
        "pivot": "The manufacturer prices excess wear at the body-shop number, not the touch-up number. A scuff is two hundred, a dent is six hundred, a wheel is eight. They add fast.",
        "close": "Coverage handles it before you do. You drive normal, you turn it in, you walk away.",
        "pushback": "Look at the wear-and-tear pricing sheet — it's printed on the back of the lease guide.",
        "follow_ups": [
            "How does your driveway look — kids, gravel, garage?",
            "Have you ever paid wear charges before?",
            "Want me to walk through the pricing schedule?"
        ],
    },

    # ----- Maintenance (3 polished — pulled from W) -----
    "W-09": {
        "customer_line": "I do my own maintenance.",
        "signal": "control",
        "soft_open": "Good. Most people don't, and it shows.",
        "pivot": "Maintenance plans aren't about replacing your wrench. They're about prepaying tomorrow's labor rate at today's price, and locking the items you don't enjoy — fluids, filters, brakes, tires.",
        "close": "Keep doing your own oil. The plan handles the things that get expensive when shops mark them up year over year.",
        "pushback": "Labor's going up. The plan freezes part of it. That's the play.",
        "follow_ups": [
            "What do you not enjoy doing yourself?",
            "Want me to itemize what's actually included?",
            "Have you priced a dealer service visit this year?"
        ],
    },
    "W-10": {
        "customer_line": "Maintenance is cheap.",
        "signal": "price",
        "soft_open": "Some of it. Not the parts you don't see coming.",
        "pivot": "Oil's cheap. Tires aren't. Brakes aren't. Coolant flushes, cabin filters, transmission services — they're scheduled, and they add up to a number nobody plans for.",
        "close": "The plan smooths the bumps. You pay one number instead of seven surprise numbers.",
        "pushback": "Pull up the maintenance schedule for this car — I'll show you what year four actually looks like.",
        "follow_ups": [
            "Have you priced a set of tires for this car?",
            "What was your last service bill?",
            "Want me to show the five-year maintenance cost on paper?"
        ],
    },
    "W-11": {
        "customer_line": "I'll just take it to my own mechanic.",
        "signal": "trust",
        "soft_open": "Loyalty to a good mechanic is real. We don't break that.",
        "pivot": "Most maintenance plans cover service at any licensed shop. You hand them the card, they bill us. The plan doesn't tell you where to go — it just pays.",
        "close": "Same mechanic, same shop. Different invoice.",
        "pushback": "Read the network language with me — most plans we sell are nationwide, not dealer-only.",
        "follow_ups": [
            "Is your guy authorized for this brand?",
            "Want to see the in-network list?",
            "Has your mechanic ever asked you for prepaid maintenance receipts?"
        ],
    },
}

# Section signal default if no override
def signal_for(section, code):
    if code in POLISHED:
        return POLISHED[code]["signal"]
    return DEFAULT_SIGNAL.get(section, "control")


def normalize_unpolished(o):
    """Convert raw box_data objection into the new schema fields by chunking."""
    t1 = (o.get("track1") or "").strip()
    t2 = (o.get("track2") or "").strip()
    close_text = (o.get("close") or "").strip()
    q = (o.get("question") or "").strip()

    # Soft open: take first sentence of track1 (or all if short)
    def first_sentence(s, max_chars=220):
        if not s:
            return ""
        # split on . ? ! but keep the punctuation
        parts = re.split(r'(?<=[.!?])\s+', s.strip())
        if not parts:
            return s[:max_chars]
        out = parts[0]
        if len(out) > max_chars and len(parts) > 1:
            out = parts[0][:max_chars]
        return out.strip()

    def trim(s, max_chars=320):
        s = (s or "").strip()
        if len(s) <= max_chars:
            return s
        return s[:max_chars].rsplit(" ", 1)[0] + "…"

    soft_open = first_sentence(t1) or first_sentence(t2)
    # Pivot: rest of track1 if any, else track2
    pivot = ""
    if t1:
        rest = t1[len(first_sentence(t1)):].strip()
        if rest:
            pivot = trim(rest, 320)
        else:
            pivot = trim(t2, 320)
    else:
        pivot = trim(t2, 320)

    close = trim(close_text, 320)
    pushback = trim(q, 200) if q else ""
    if not pushback and t2 and not pivot.startswith(t2[:30]):
        # use track2 as pushback if pivot didn't use it
        pushback = trim(t2, 200)

    # Follow-ups: generate 2 generic prompts; user can edit
    follow_ups = [
        "What about this part lands wrong for you?",
        "Want me to show this in writing?",
    ]

    return {
        "customer_line": o["objection"],
        "signal": signal_for(o["section"], o["code"]),
        "soft_open": soft_open,
        "pivot": pivot,
        "close": close,
        "pushback": pushback,
        "follow_ups": follow_ups,
    }


def main():
    with open(SRC, "r") as f:
        src = json.load(f)

    out = []
    polished_count = 0
    by_code = {o["code"]: o for o in src["objections"]}

    # Walk source order to keep stable IDs
    for o in src["objections"]:
        code = o["code"]
        category = o["section"]
        category_code = o["section_code"]

        if code in POLISHED:
            p = POLISHED[code]
            entry = {
                "id": code,
                "category": category,
                "category_code": category_code,
                "title": p["customer_line"],
                "customer_line": p["customer_line"],
                "signal": p["signal"],
                "soft_open": p["soft_open"],
                "pivot": p["pivot"],
                "close": p["close"],
                "pushback": p["pushback"],
                "follow_ups": p["follow_ups"],
                "aliases": o.get("aliases", []),
                "keywords": o.get("keywords", ""),
                "polished": True,
                "page": o.get("page"),
            }
            polished_count += 1
        else:
            n = normalize_unpolished(o)
            entry = {
                "id": code,
                "category": category,
                "category_code": category_code,
                "title": o["objection"],
                "customer_line": n["customer_line"],
                "signal": n["signal"],
                "soft_open": n["soft_open"],
                "pivot": n["pivot"],
                "close": n["close"],
                "pushback": n["pushback"],
                "follow_ups": n["follow_ups"],
                "aliases": o.get("aliases", []),
                "keywords": o.get("keywords", ""),
                "polished": False,
                "page": o.get("page"),
            }
        out.append(entry)

    # Add the cash buyer polished as a new objection if X-04 doesn't exist as cash
    # Check existing codes
    if "X-04" in by_code:
        # find the polished X-04 - already added above if it was already in box_data?
        pass
    else:
        # ensure cash buyer exists - it's in POLISHED but only added if in source.
        # Add as standalone
        cash = POLISHED["X-04"]
        out.append({
            "id": "SP-CASH",
            "category": "General & Brush-Offs",
            "category_code": "X",
            "title": cash["customer_line"],
            "customer_line": cash["customer_line"],
            "signal": cash["signal"],
            "soft_open": cash["soft_open"],
            "pivot": cash["pivot"],
            "close": cash["close"],
            "pushback": cash["pushback"],
            "follow_ups": cash["follow_ups"],
            "aliases": ["paying cash", "cash buyer", "i'm a cash buyer", "buying cash", "no financing"],
            "keywords": "cash buyer paying cash no loan no finance",
            "polished": True,
            "page": None,
        })
        polished_count += 1

    # Categories meta
    categories = {}
    section_codes = {}
    for o in src["objections"]:
        categories.setdefault(o["section"], 0)
        categories[o["section"]] += 1
        section_codes[o["section_code"]] = o["section"]

    payload = {
        "meta": {
            "title": "The Box",
            "subtitle": "by Still Point",
            "source": "Adapted from Zach Salter's Finance Office Field Manual",
            "polished_count": polished_count,
            "total_count": len(out),
        },
        "categories": [
            {"code": k, "name": v} for k, v in section_codes.items()
        ],
        "objections": out,
    }
    with open(OUT, "w") as f:
        json.dump(payload, f, indent=2, ensure_ascii=False)
    print(f"Wrote {OUT}")
    print(f"Total: {len(out)}, Polished: {polished_count}")


if __name__ == "__main__":
    main()
